import {Routes, Route} from 'react-router-dom';
import {CreatePost, Navbar, PostDetail, Home} from './Index';

function App() {
  return (
    <div className="container">
    <Navbar />
   <Routes>
  
   <Route exact path="/" element={<Home />}></Route>

    <Route exact path='/post/:postId' element ={<PostDetail />}/>
    <Route exact path='/create-post' element ={<CreatePost />}/>
    </Routes>
    </div>
  );
}

export default App;
