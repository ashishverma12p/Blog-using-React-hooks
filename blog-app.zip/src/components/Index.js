
import Home from "./Home";
import PostDetail from "./PostDetail";
import CreatePost from "./CreatePost";
import Navbar from "./Navbar";

export  { Home, PostDetail, CreatePost, Navbar};
