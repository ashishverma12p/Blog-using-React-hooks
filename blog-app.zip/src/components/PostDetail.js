function PostDetail() {
    return (
      <div className="PostDetail">PostDetail </div>
    );
  }
  
  export default PostDetail;