// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import 'firebase/firestore';
import { firestore } from "firebase/firestore";

// Your  app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDqNm_5OthnkRUFQxdagD3O4XImsuYySug",
  authDomain: "react-hooks-blog-9af1b.firebaseapp.com",
  projectId: "react-hooks-blog-9af1b",
  storageBucket: "react-hooks-blog-9af1b.appspot.com",
  messagingSenderId: "481842438159",
  appId: "1:481842438159:web:11f764bd0102b56a38837a"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const firestore = firebase.firestore();